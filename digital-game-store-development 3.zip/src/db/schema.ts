import {
  boolean,
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

export const games = pgTable("games", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  titleAr: text("title_ar").notNull(),
  slug: text("slug").notNull().unique(),
  description: text("description").notNull(),
  descriptionAr: text("description_ar").notNull(),
  price: integer("price").notNull(),
  originalPrice: integer("original_price").notNull(),
  imageUrl: text("image_url").notNull(),
  publisher: text("publisher").notNull(),
  category: text("category").notNull(),
  platforms: text("platforms").array().notNull(),
  exclusive: text("exclusive"),
  featured: boolean("featured").notNull().default(false),
  hot: boolean("hot").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  customerName: text("customer_name").notNull(),
  phone: text("phone").notNull(),
  email: text("email"),
  paymentMethod: text("payment_method").notNull(),
  total: integer("total").notNull(),
  status: text("status").notNull().default("pending"),
  notes: text("notes"),
  items: jsonb("items")
    .$type<
      {
        gameId: number;
        title: string;
        titleAr: string;
        price: number;
        qty: number;
        imageUrl: string;
      }[]
    >()
    .notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type Game = typeof games.$inferSelect;
export type NewGame = typeof games.$inferInsert;
export type Order = typeof orders.$inferSelect;
