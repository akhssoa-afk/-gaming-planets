import { db } from "@/db";
import { games } from "@/db/schema";
import { SEED_GAMES } from "@/db/seed-data";

export async function ensureSeeded() {
  const existing = await db.select({ id: games.id }).from(games).limit(1);
  if (existing.length > 0) return;
  await db.insert(games).values(SEED_GAMES);
}
