"use client";

import { useState } from "react";
import type { Game } from "@/db/schema";
import { useCart } from "@/components/cart-provider";
import Link from "next/link";

export function AddToCartButton({ game }: { game: Game }) {
  const { add } = useCart();
  const [added, setAdded] = useState(false);

  function onAdd() {
    add({
      gameId: game.id,
      title: game.title,
      titleAr: game.titleAr,
      price: game.price,
      imageUrl: game.imageUrl,
      slug: game.slug,
    });
    setAdded(true);
  }

  return (
    <div className="mt-6 flex flex-wrap gap-3">
      <button type="button" onClick={onAdd} className="glow-btn rounded-full px-8 py-3 font-bold">
        {added ? "تمت الإضافة للسلة ✓" : "إضافة للسلة"}
      </button>
      <Link href="/checkout" onClick={onAdd} className="rounded-full border border-violet-400/30 px-8 py-3 font-bold">
        اشترِ الآن
      </Link>
    </div>
  );
}
