import Link from "next/link";
import { CATEGORIES } from "@/lib/constants";

function Planet({ hue, active, kind }: { hue: number; active?: boolean; kind: string }) {
  const c1 = `hsl(${hue} 80% 58%)`;
  const c2 = `hsl(${hue} 70% 32%)`;
  return (
    <span
      className={`planet-float relative grid h-16 w-16 place-items-center rounded-full ${
        active ? "ring-2 ring-violet-400 ring-offset-2 ring-offset-[#070414]" : ""
      }`}
      style={{ animationDelay: `${hue % 7}00ms` }}
    >
      <svg viewBox="0 0 80 80" className="h-16 w-16 drop-shadow-[0_8px_16px_rgba(0,0,0,0.45)]">
        <defs>
          <radialGradient id={`p-${kind}`} cx="35%" cy="30%">
            <stop offset="0%" stopColor={c1} />
            <stop offset="100%" stopColor={c2} />
          </radialGradient>
        </defs>
        {kind === "all" && (
          <ellipse cx="40" cy="42" rx="34" ry="10" fill="none" stroke="#c4b5fd" strokeWidth="3" transform="rotate(-18 40 40)" />
        )}
        <circle cx="40" cy="40" r="22" fill={`url(#p-${kind})`} />
        <circle cx="32" cy="32" r="6" fill="white" opacity="0.18" />
        {kind === "sports" && <circle cx="40" cy="40" r="8" fill="none" stroke="white" strokeWidth="1.4" opacity="0.7" />}
        {kind === "fighting" && <circle cx="48" cy="34" r="4" fill="#ef4444" opacity="0.8" />}
      </svg>
    </span>
  );
}

export function CategoryPlanets({ active = "all" }: { active?: string }) {
  return (
    <div className="flex gap-5 overflow-x-auto pb-2">
      {CATEGORIES.map((cat) => (
        <Link
          key={cat.key}
          href={cat.key === "all" ? "/games" : `/games?category=${cat.key}`}
          className="flex min-w-[76px] flex-col items-center gap-2 text-center"
        >
          <Planet hue={cat.hue} active={active === cat.key} kind={cat.key} />
          <span className={`text-xs font-semibold ${active === cat.key ? "text-white" : "text-violet-100/70"}`}>
            {cat.label}
          </span>
        </Link>
      ))}
    </div>
  );
}
