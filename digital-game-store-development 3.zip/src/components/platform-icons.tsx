export function SteamIcon({ className = "h-4 w-4" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="currentColor" aria-hidden>
      <path d="M12 2a10 10 0 0 0-10 9.2L8.4 14a3.2 3.2 0 0 1 1.9-.3l2.7-3.9a2.6 2.6 0 1 1 2.6 2.6l-3.8 2.8c.1.3.1.7 0 1.1A3.2 3.2 0 0 1 8 19.4L3.2 17.4A10 10 0 1 0 12 2zm-3.9 14.6a1.7 1.7 0 1 0-1.2 2.2c.5.1 1-.1 1.4-.5l1.6.7a1.7 1.7 0 1 0 .2-1.6z" />
    </svg>
  );
}

export function PlaystationIcon({ className = "h-4 w-4" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="currentColor" aria-hidden>
      <path d="M8.5 15.6c.2 1.6 1.5 2.2 3.6 1.4l7.2-2.6v2.3l-7.5 2.7c-3.2 1.1-6-.4-6.3-3.4V8.4l3 .9zm10.3-2.3-3.3 1.2V8.4c0-1.5-.6-2.3-1.9-2.3-.8 0-1.6.3-2.4.8V4.6c.8-.4 1.7-.6 2.6-.6 2.6 0 5 1.3 5 4.6zm-13.3.4V8.8c0-2.6 1.6-4 4.3-4 .8 0 1.7.2 2.5.6v2.4c-.8-.6-1.6-1-2.4-1-1.3 0-2 .8-2 2.3v3.3z" />
    </svg>
  );
}

export function XboxIcon({ className = "h-4 w-4" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="currentColor" aria-hidden>
      <path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10 10-4.5 10-10S17.5 2 12 2zm6.7 13.4c-1.6 2.8-4 4.4-6.7 4.4s-5.1-1.6-6.7-4.4c1.7-1.4 3.8-3.6 6.7-7.3 2.9 3.7 5 5.9 6.7 7.3zM7.2 6.3C8.6 5.2 10.2 4.6 12 4.6s3.4.6 4.8 1.7c-1.4.9-3 2.4-4.8 4.6-1.8-2.2-3.4-3.7-4.8-4.6z" />
    </svg>
  );
}

export function NintendoIcon({ className = "h-4 w-4" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="currentColor" aria-hidden>
      <path d="M7.2 4h3.2v16H7.8c-2.6 0-4.8-2.1-4.8-4.8V8.8C3 6.1 5.1 4 7.8 4zm.6 6.2a1.4 1.4 0 1 0 0 2.8 1.4 1.4 0 0 0 0-2.8zM13.6 4h3.2c2.7 0 4.8 2.1 4.8 4.8v6.4c0 2.7-2.1 4.8-4.8 4.8h-3.2zm5 8.8a1.4 1.4 0 1 0-2.8 0 1.4 1.4 0 0 0 2.8 0z" />
    </svg>
  );
}

export function PlatformGlyph({
  platform,
  className = "h-4 w-4",
}: {
  platform: string;
  className?: string;
}) {
  if (platform === "steam") return <SteamIcon className={className} />;
  if (platform === "playstation") return <PlaystationIcon className={className} />;
  if (platform === "xbox") return <XboxIcon className={className} />;
  if (platform === "nintendo") return <NintendoIcon className={className} />;
  return null;
}

export function MastercardMark() {
  return (
    <svg viewBox="0 0 48 30" className="h-7 w-11" aria-hidden>
      <rect width="48" height="30" rx="6" fill="#1a1a1a" />
      <circle cx="19" cy="15" r="8" fill="#eb001b" />
      <circle cx="29" cy="15" r="8" fill="#f79e1b" />
      <path d="M24 9.2a8 8 0 0 0 0 11.6 8 8 0 0 0 0-11.6z" fill="#ff5f00" />
    </svg>
  );
}

export function ApplePayMark() {
  return (
    <div className="flex h-7 items-center rounded-md bg-black px-2 text-[11px] font-semibold tracking-wide text-white">
      <svg viewBox="0 0 14 17" className="mr-1 h-3.5 w-3" fill="currentColor" aria-hidden>
        <path d="M11.4 8.9c0-2 1.6-2.9 1.7-3-1-1.4-2.5-1.6-3-1.6-1.3-.1-2.5.8-3.1.8s-1.6-.7-2.7-.7c-1.4 0-2.7.8-3.4 2.1-1.5 2.5-.4 6.3 1 8.3.7 1 1.5 2.1 2.6 2 1 .1 1.4-.7 2.7-.7s1.6.7 2.7.6c1.1 0 1.8-1 2.5-2 .8-1.1 1.1-2.2 1.1-2.2s-2.1-.8-2.1-3.4zM9.6 3.3c.6-.7 1-1.7.9-2.7-1 .1-2.1.7-2.7 1.5-.6.7-1.1 1.7-.9 2.6 1 0 2-.6 2.7-1.4z" />
      </svg>
      Pay
    </div>
  );
}
