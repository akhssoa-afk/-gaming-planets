import Link from "next/link";
import { STORE, whatsappLink } from "@/lib/constants";
import { ApplePayMark, MastercardMark } from "@/components/platform-icons";
import { Logo } from "@/components/logo";

export function Footer() {
  return (
    <footer className="mt-10 border-t border-violet-500/15 bg-[#08051a] px-4 py-10 lg:px-7">
      <div className="grid gap-8 md:grid-cols-4">
        <div>
          <Logo />
          <p className="mt-3 text-sm leading-7 text-violet-100/60">
            متجر ألعاب رقمية سعودي. ستيم، سوني، إكس بوكس. تسليم فوري ودعم على الخاص.
          </p>
        </div>
        <div>
          <h3 className="mb-3 font-bold">روابط</h3>
          <div className="flex flex-col gap-2 text-sm text-violet-100/70">
            <Link href="/games">جميع الألعاب</Link>
            <Link href="/offers">العروض</Link>
            <Link href="/platforms">المنصات</Link>
            <Link href="/support">الدعم</Link>
          </div>
        </div>
        <div>
          <h3 className="mb-3 font-bold">الدعم</h3>
          <div className="flex flex-col gap-2 text-sm text-violet-100/70">
            <a href={whatsappLink("مرحباً، أحتاج مساعدة")} target="_blank" rel="noreferrer">
              واتساب: {STORE.whatsapp}
            </a>
            <a href={`mailto:${STORE.email}`}>{STORE.email}</a>
          </div>
        </div>
        <div>
          <h3 className="mb-3 font-bold">طرق الدفع</h3>
          <div className="flex items-center gap-3">
            <MastercardMark />
            <ApplePayMark />
          </div>
          <p className="mt-3 text-xs text-violet-100/45">الدفع يتم تأكيده عبر واتساب والتسليم فوري.</p>
        </div>
      </div>
      <p className="mt-8 text-center text-xs text-violet-200/40">
        © {new Date().getFullYear()} Gaming Planets — جميع الحقوق محفوظة
      </p>
    </footer>
  );
}
