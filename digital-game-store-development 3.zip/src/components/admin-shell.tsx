"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import type { ReactNode } from "react";
import { Logo } from "@/components/logo";

const LINKS = [
  { href: "/admin", label: "نظرة عامة" },
  { href: "/admin/games", label: "الألعاب والصور" },
  { href: "/admin/orders", label: "الطلبات" },
];

export function AdminShell({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();

  async function logout() {
    await fetch("/api/admin/logout", { method: "POST" });
    router.push("/admin/login");
    router.refresh();
  }

  return (
    <div className="min-h-screen bg-[#070414]">
      <header className="flex items-center justify-between border-b border-violet-500/15 px-5 py-3">
        <div className="flex items-center gap-6">
          <Logo size="sm" />
          <span className="rounded-full bg-violet-600/20 px-3 py-1 text-xs font-bold text-violet-200">
            لوحة المالك
          </span>
          <nav className="hidden gap-4 text-sm font-semibold md:flex">
            {LINKS.map((l) => (
              <Link
                key={l.href}
                href={l.href}
                className={pathname === l.href ? "text-white" : "text-violet-200/60 hover:text-white"}
              >
                {l.label}
              </Link>
            ))}
          </nav>
        </div>
        <div className="flex items-center gap-3 text-sm">
          <Link href="/" className="text-violet-200/70">
            عرض المتجر
          </Link>
          <button onClick={logout} className="rounded-full border border-violet-500/30 px-3 py-1.5">
            خروج
          </button>
        </div>
      </header>
      <div className="flex gap-3 border-b border-violet-500/10 px-5 py-2 md:hidden">
        {LINKS.map((l) => (
          <Link key={l.href} href={l.href} className="text-sm text-violet-200/70">
            {l.label}
          </Link>
        ))}
      </div>
      <div className="px-5 py-6">{children}</div>
    </div>
  );
}
