"use client";

import Link from "next/link";
import type { Game } from "@/db/schema";
import { useCart } from "@/components/cart-provider";
import { discountOf } from "@/lib/constants";
import { PlatformGlyph } from "@/components/platform-icons";
import { useState } from "react";

export function GameCard({ game }: { game: Game }) {
  const { add } = useCart();
  const [added, setAdded] = useState(false);
  const discount = discountOf(game.price, game.originalPrice);

  function onAdd() {
    add({
      gameId: game.id,
      title: game.title,
      titleAr: game.titleAr,
      price: game.price,
      imageUrl: game.imageUrl,
      slug: game.slug,
    });
    setAdded(true);
    setTimeout(() => setAdded(false), 1200);
  }

  return (
    <article className="card-glow group flex h-full flex-col overflow-hidden rounded-3xl">
      <Link href={`/games/${game.slug}`} className="relative block aspect-[4/5] overflow-hidden">
        <img
          src={game.imageUrl}
          alt={game.titleAr}
          className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0b0718] via-transparent to-black/10" />
        {discount > 0 && (
          <span className="absolute top-3 right-3 rounded-lg bg-red-500 px-2 py-0.5 text-xs font-black">
            -{discount}%
          </span>
        )}
        {game.exclusive && (
          <span className="absolute top-3 left-3 rounded-lg bg-violet-600/90 px-2 py-0.5 text-[10px] font-bold">
            حصري
          </span>
        )}
        <div className="absolute bottom-3 left-3 flex items-center gap-1.5 text-white/90">
          {game.platforms.map((p) => (
            <span key={p} className="rounded-md bg-black/45 p-1 backdrop-blur">
              <PlatformGlyph platform={p} className="h-3.5 w-3.5" />
            </span>
          ))}
        </div>
      </Link>
      <div className="flex flex-1 flex-col gap-2 p-3.5">
        <Link href={`/games/${game.slug}`} className="line-clamp-1 text-sm font-bold">
          {game.title}
        </Link>
        <p className="line-clamp-1 text-xs text-violet-200/60">{game.titleAr}</p>
        <div className="mt-auto flex items-baseline gap-2">
          {discount > 0 && (
            <span className="text-xs text-violet-200/40 line-through">{game.originalPrice} SAR</span>
          )}
          <span className="text-lg font-black text-violet-300">{game.price} SAR</span>
        </div>
        <button type="button" onClick={onAdd} className="glow-btn mt-1 w-full rounded-xl py-2.5 text-sm font-bold">
          {added ? "تمت الإضافة ✓" : "إضافة للسلة"}
        </button>
      </div>
    </article>
  );
}
