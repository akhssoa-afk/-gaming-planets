"use client";

import { usePathname } from "next/navigation";
import { STORE, whatsappLink } from "@/lib/constants";

export function WhatsAppButton() {
  const pathname = usePathname();
  if (pathname?.startsWith("/admin")) return null;

  return (
    <a
      href={whatsappLink("مرحباً Gaming Planets، أريد الاستفسار عن الألعاب")}
      target="_blank"
      rel="noopener noreferrer"
      className="wa-pulse fixed bottom-5 left-5 z-50 flex h-14 w-14 items-center justify-center rounded-full bg-[#25d366] text-white shadow-[0_10px_30px_rgba(37,211,102,0.45)] transition hover:scale-105"
      aria-label="تواصل واتساب"
      title={`واتساب ${STORE.whatsapp}`}
    >
      <svg viewBox="0 0 24 24" className="h-8 w-8 fill-current" aria-hidden>
        <path d="M20.5 3.5A11 11 0 0 0 2.4 17.7L1 23l5.4-1.4A11 11 0 0 0 12 23a11 11 0 0 0 8.5-19.5zM12 21.1a9.1 9.1 0 0 1-4.6-1.3l-.3-.2-3.2.8.9-3.1-.2-.3A9.1 9.1 0 1 1 12 21.1zm5-6.8c-.3-.1-1.6-.8-1.9-.9s-.4-.1-.6.1-.7.9-.9 1.1-.3.2-.6.1a7.4 7.4 0 0 1-2.2-1.4 8.2 8.2 0 0 1-1.5-1.9c-.2-.3 0-.4.1-.6l.5-.6.3-.4v-.4l-.9-2.2c-.2-.6-.5-.5-.6-.5h-.5a1 1 0 0 0-.7.3 3 3 0 0 0-.9 2.2 5.2 5.2 0 0 0 1.1 2.8 11.8 11.8 0 0 0 4.5 4 15 15 0 0 0 1.5.5 3.6 3.6 0 0 0 1.6.1 2.7 2.7 0 0 0 1.8-1.2 2.2 2.2 0 0 0 .2-1.2c0-.2-.2-.3-.4-.4z" />
      </svg>
    </a>
  );
}
