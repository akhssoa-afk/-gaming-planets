import Link from "next/link";

export function Logo({ size = "md" }: { size?: "sm" | "md" | "lg" }) {
  const img = size === "lg" ? "h-16 w-16" : size === "sm" ? "h-9 w-9" : "h-12 w-12";
  const title = size === "lg" ? "text-2xl" : size === "sm" ? "text-sm" : "text-lg";
  return (
    <Link href="/" className="flex items-center gap-2.5">
      <img
        src="/images/logo-alien.png"
        alt="رجل فضائي"
        className={`alien-heartbeat rounded-full object-cover ${img}`}
      />
      <span className={`leading-tight font-black tracking-wide ${title}`}>
        <span className="block bg-gradient-to-l from-violet-300 via-fuchsia-300 to-indigo-300 bg-clip-text text-transparent">
          GAMING
        </span>
        <span className="-mt-1 block text-white">PLANETS</span>
      </span>
    </Link>
  );
}
