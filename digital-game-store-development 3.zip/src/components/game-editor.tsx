"use client";

import { FormEvent, useState } from "react";
import { useRouter } from "next/navigation";
import type { Game } from "@/db/schema";
import { CATEGORIES, PLATFORMS, PUBLISHERS } from "@/lib/constants";

export function GameEditor({ game }: { game?: Game }) {
  const router = useRouter();
  const [imageUrl, setImageUrl] = useState(game?.imageUrl || "");
  const [platforms, setPlatforms] = useState<string[]>(game?.platforms || ["steam"]);
  const [status, setStatus] = useState("");
  const [busy, setBusy] = useState(false);

  function togglePlatform(key: string) {
    setPlatforms((prev) => (prev.includes(key) ? prev.filter((p) => p !== key) : [...prev, key]));
  }

  async function upload(file: File) {
    const data = new FormData();
    data.append("file", file);
    const res = await fetch("/api/admin/upload", { method: "POST", body: data });
    const json = (await res.json()) as { url?: string; error?: string };
    if (!res.ok || !json.url) throw new Error(json.error || "فشل الرفع");
    setImageUrl(json.url);
  }

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setBusy(true);
    setStatus("");
    const form = new FormData(e.currentTarget);
    const payload = {
      title: String(form.get("title") || ""),
      titleAr: String(form.get("titleAr") || ""),
      slug: String(form.get("slug") || ""),
      descriptionAr: String(form.get("descriptionAr") || ""),
      price: Number(form.get("price")),
      originalPrice: Number(form.get("originalPrice")),
      imageUrl,
      publisher: String(form.get("publisher") || "ea"),
      category: String(form.get("category") || "action"),
      exclusive: String(form.get("exclusive") || "") || null,
      featured: form.get("featured") === "on",
      hot: form.get("hot") === "on",
      platforms,
    };

    try {
      const url = game ? `/api/admin/games/${game.id}` : "/api/admin/games";
      const res = await fetch(url, {
        method: game ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const json = (await res.json()) as { error?: string };
      if (!res.ok) throw new Error(json.error || "فشل الحفظ");
      router.push("/admin/games");
      router.refresh();
    } catch (err) {
      setStatus(err instanceof Error ? err.message : "خطأ");
      setBusy(false);
    }
  }

  async function remove() {
    if (!game) return;
    if (!confirm("حذف اللعبة؟")) return;
    await fetch(`/api/admin/games/${game.id}`, { method: "DELETE" });
    router.push("/admin/games");
    router.refresh();
  }

  return (
    <form onSubmit={onSubmit} className="grid gap-6 lg:grid-cols-[280px_1fr]">
      <div className="card-glow rounded-3xl p-4">
        <p className="mb-2 text-sm font-bold">صورة اللعبة</p>
        <div className="overflow-hidden rounded-2xl bg-black/30">
          {imageUrl ? (
            <img src={imageUrl} alt="" className="aspect-[3/4] w-full object-cover" />
          ) : (
            <div className="grid aspect-[3/4] place-items-center text-sm text-violet-200/40">بدون صورة</div>
          )}
        </div>
        <label className="glow-btn mt-3 flex cursor-pointer justify-center rounded-full py-2 text-sm font-bold">
          رفع صورة جديدة
          <input
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) upload(file).catch((err: Error) => setStatus(err.message));
            }}
          />
        </label>
        <label className="mt-3 block text-xs text-violet-200/70">
          أو رابط صورة
          <input
            value={imageUrl}
            onChange={(e) => setImageUrl(e.target.value)}
            className="mt-1 w-full rounded-xl border border-violet-500/20 bg-[#0d0a1c] px-3 py-2 text-sm"
          />
        </label>
      </div>
      <div className="card-glow space-y-4 rounded-3xl p-5">
        <div className="grid gap-3 md:grid-cols-2">
          <label className="text-sm">
            الاسم بالإنجليزي
            <input
              name="title"
              defaultValue={game?.title}
              required
              className="mt-1 w-full rounded-xl border border-violet-500/20 bg-[#0d0a1c] px-3 py-2"
            />
          </label>
          <label className="text-sm">
            الاسم بالعربي
            <input
              name="titleAr"
              defaultValue={game?.titleAr}
              required
              className="mt-1 w-full rounded-xl border border-violet-500/20 bg-[#0d0a1c] px-3 py-2"
            />
          </label>
        </div>
        {!game && (
          <label className="block text-sm">
            المعرف (slug)
            <input
              name="slug"
              className="mt-1 w-full rounded-xl border border-violet-500/20 bg-[#0d0a1c] px-3 py-2"
            />
          </label>
        )}
        <label className="block text-sm">
          الوصف
          <textarea
            name="descriptionAr"
            defaultValue={game?.descriptionAr}
            rows={3}
            className="mt-1 w-full rounded-xl border border-violet-500/20 bg-[#0d0a1c] px-3 py-2"
          />
        </label>
        <div className="grid gap-3 md:grid-cols-2">
          <label className="text-sm">
            السعر (20-70)
            <input
              name="price"
              type="number"
              min={20}
              max={70}
              defaultValue={game?.price ?? 29}
              className="mt-1 w-full rounded-xl border border-violet-500/20 bg-[#0d0a1c] px-3 py-2"
            />
          </label>
          <label className="text-sm">
            السعر قبل الخصم
            <input
              name="originalPrice"
              type="number"
              min={20}
              defaultValue={game?.originalPrice ?? 49}
              className="mt-1 w-full rounded-xl border border-violet-500/20 bg-[#0d0a1c] px-3 py-2"
            />
          </label>
        </div>
        <div className="grid gap-3 md:grid-cols-3">
          <label className="text-sm">
            الناشر
            <select
              name="publisher"
              defaultValue={game?.publisher ?? "ea"}
              className="mt-1 w-full rounded-xl border border-violet-500/20 bg-[#0d0a1c] px-3 py-2"
            >
              {PUBLISHERS.map((p) => (
                <option key={p.key} value={p.key}>
                  {p.labelAr}
                </option>
              ))}
            </select>
          </label>
          <label className="text-sm">
            التصنيف
            <select
              name="category"
              defaultValue={game?.category ?? "action"}
              className="mt-1 w-full rounded-xl border border-violet-500/20 bg-[#0d0a1c] px-3 py-2"
            >
              {CATEGORIES.filter((c) => c.key !== "all").map((c) => (
                <option key={c.key} value={c.key}>
                  {c.label}
                </option>
              ))}
            </select>
          </label>
          <label className="text-sm">
            حصري
            <select
              name="exclusive"
              defaultValue={game?.exclusive ?? ""}
              className="mt-1 w-full rounded-xl border border-violet-500/20 bg-[#0d0a1c] px-3 py-2"
            >
              <option value="">لا</option>
              {PLATFORMS.map((p) => (
                <option key={p.key} value={p.key}>
                  {p.label}
                </option>
              ))}
            </select>
          </label>
        </div>
        <div>
          <p className="mb-2 text-sm">المنصات</p>
          <div className="flex flex-wrap gap-2">
            {PLATFORMS.map((p) => (
              <button
                type="button"
                key={p.key}
                onClick={() => togglePlatform(p.key)}
                className={`rounded-full px-3 py-1 text-sm ${
                  platforms.includes(p.key) ? "bg-violet-600" : "bg-white/5"
                }`}
              >
                {p.label}
              </button>
            ))}
          </div>
        </div>
        <div className="flex gap-6 text-sm">
          <label className="flex items-center gap-2">
            <input type="checkbox" name="featured" defaultChecked={game?.featured} /> أشهر الألعاب
          </label>
          <label className="flex items-center gap-2">
            <input type="checkbox" name="hot" defaultChecked={game?.hot} /> عرض ساخن
          </label>
        </div>
        {status && <p className="text-sm text-red-400">{status}</p>}
        <div className="flex gap-3">
          <button disabled={busy} className="glow-btn rounded-full px-6 py-2.5 font-bold">
            {busy ? "جارٍ الحفظ..." : "حفظ"}
          </button>
          {game && (
            <button type="button" onClick={remove} className="rounded-full border border-red-400/40 px-5 py-2.5 text-red-300">
              حذف
            </button>
          )}
        </div>
      </div>
    </form>
  );
}
