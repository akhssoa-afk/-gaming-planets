"use client";

import { useState, type ReactNode } from "react";
import { Header } from "@/components/header";
import { Sidebar } from "@/components/sidebar";
import { Footer } from "@/components/footer";

export function StoreFrame({ children }: { children: ReactNode }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="min-h-screen">
      <Sidebar open={open} onClose={() => setOpen(false)} />
      <div className="lg:mr-[280px]">
        <Header onMenu={() => setOpen(true)} />
        <main className="px-4 py-5 lg:px-7">{children}</main>
        <Footer />
      </div>
    </div>
  );
}
