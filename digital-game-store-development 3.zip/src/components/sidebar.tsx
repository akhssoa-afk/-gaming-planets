"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Logo } from "@/components/logo";
import {
  NintendoIcon,
  PlaystationIcon,
  SteamIcon,
  XboxIcon,
} from "@/components/platform-icons";

const LINKS = [
  { href: "/", label: "الصفحة الرئيسية", icon: "home" },
  { href: "/games", label: "جميع الألعاب", icon: "pad" },
  { href: "/platforms", label: "المنصات", icon: "layers" },
  { href: "/offers", label: "العروض الخاصة", icon: "tag" },
  { href: "/cart", label: "سلة المشتريات", icon: "cart" },
  { href: "/account", label: "حسابي", icon: "user" },
];

function Glyph({ name }: { name: string }) {
  const cls = "h-5 w-5";
  if (name === "home")
    return (
      <svg viewBox="0 0 24 24" className={cls} fill="currentColor">
        <path d="M12 3 3 11h2v9h6v-6h2v6h6v-9h2z" />
      </svg>
    );
  if (name === "pad")
    return (
      <svg viewBox="0 0 24 24" className={cls} fill="currentColor">
        <path d="M7 7h10a6 6 0 0 1 0 12H7A6 6 0 0 1 7 7zm2.2 4v2.2H7V11zm2.2-2.2V11H9.2V8.8zM17 12.2a1.1 1.1 0 1 0 0-2.2 1.1 1.1 0 0 0 0 2.2zm-1.8 1.8a1.1 1.1 0 1 0 0-2.2 1.1 1.1 0 0 0 0 2.2z" />
      </svg>
    );
  if (name === "layers")
    return (
      <svg viewBox="0 0 24 24" className={cls} fill="currentColor">
        <path d="M12 3 3 8l9 5 9-5zm0 8L3 16l9 5 9-5z" />
      </svg>
    );
  if (name === "tag")
    return (
      <svg viewBox="0 0 24 24" className={cls} fill="currentColor">
        <path d="M20 12 12 4H5v7l8 8zM7.5 8.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3z" />
      </svg>
    );
  if (name === "cart")
    return (
      <svg viewBox="0 0 24 24" className={cls} fill="none" stroke="currentColor" strokeWidth="1.8">
        <path d="M6 6h15l-1.5 9h-12z" />
        <path d="M6 6 5 3H2" />
      </svg>
    );
  return (
    <svg viewBox="0 0 24 24" className={cls} fill="none" stroke="currentColor" strokeWidth="1.8">
      <circle cx="12" cy="8" r="3.2" />
      <path d="M5 19c1.5-3.2 4-5 7-5s5.5 1.8 7 5" />
    </svg>
  );
}

export function Sidebar({ open, onClose }: { open: boolean; onClose: () => void }) {
  const pathname = usePathname();

  return (
    <>
      <div
        className={`fixed inset-0 z-40 bg-black/60 lg:hidden ${open ? "block" : "hidden"}`}
        onClick={onClose}
      />
      <aside
        className={`fixed top-0 right-0 z-50 flex h-screen w-[280px] flex-col border-l border-violet-500/15 bg-[#0a071c] transition-transform duration-300 ${
          open ? "translate-x-0" : "translate-x-full lg:translate-x-0"
        }`}
      >
        <div className="px-5 pt-6 pb-4">
          <Logo />
        </div>
        <nav className="flex flex-1 flex-col gap-1.5 px-3">
          {LINKS.map((item) => {
            const active = pathname === item.href;
            return (
              <Link
                key={item.href}
                href={item.href}
                onClick={onClose}
                className={`flex items-center justify-between rounded-2xl px-4 py-3 text-sm font-semibold ${
                  active ? "side-active text-white" : "text-violet-100/75 hover:bg-white/5"
                }`}
              >
                <span>{item.label}</span>
                <Glyph name={item.icon} />
              </Link>
            );
          })}
          <div className="mx-2 my-4 h-px bg-violet-500/20" />
          <p className="px-3 pb-3 text-xs text-violet-200/50">متوفر لجميع المنصات</p>
          <div className="grid grid-cols-4 gap-2 px-2">
            <Link href="/platforms/steam" onClick={onClose} className="flex flex-col items-center gap-1 text-[10px] text-violet-100/70">
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/5">
                <SteamIcon className="h-5 w-5" />
              </span>
              Steam
            </Link>
            <Link href="/platforms/playstation" onClick={onClose} className="flex flex-col items-center gap-1 text-[10px] text-violet-100/70">
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/5 text-sky-400">
                <PlaystationIcon className="h-5 w-5" />
              </span>
              PlayStation
            </Link>
            <Link href="/platforms/xbox" onClick={onClose} className="flex flex-col items-center gap-1 text-[10px] text-violet-100/70">
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/5 text-green-500">
                <XboxIcon className="h-5 w-5" />
              </span>
              Xbox
            </Link>
            <Link href="/platforms/nintendo" onClick={onClose} className="flex flex-col items-center gap-1 text-[10px] text-violet-100/70">
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/5 text-red-500">
                <NintendoIcon className="h-5 w-5" />
              </span>
              Nintendo
            </Link>
          </div>
        </nav>
        <div className="relative m-3 overflow-hidden rounded-3xl">
          <img src="/images/space-planets.jpg" alt="" className="h-44 w-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0a071c] via-[#0a071c]/30 to-transparent" />
          <p className="absolute right-4 bottom-4 text-right text-lg leading-7 font-black">
            أهلاً بك في عالم
            <br />
            <span className="bg-gradient-to-l from-fuchsia-300 to-violet-300 bg-clip-text text-transparent">
              الألعاب 🚀
            </span>
          </p>
        </div>
      </aside>
    </>
  );
}
