"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { FormEvent, useState } from "react";
import { Logo } from "@/components/logo";
import { useCart } from "@/components/cart-provider";

const NAV = [
  { href: "/", label: "الصفحة الرئيسية" },
  { href: "/platforms", label: "المنصات" },
  { href: "/offers", label: "العروض" },
  { href: "/support", label: "الدعم" },
];

export function Header({ onMenu }: { onMenu: () => void }) {
  const pathname = usePathname();
  const router = useRouter();
  const { count } = useCart();
  const [q, setQ] = useState("");

  function search(e: FormEvent) {
    e.preventDefault();
    const term = q.trim();
    router.push(term ? `/search?q=${encodeURIComponent(term)}` : "/games");
  }

  return (
    <header className="sticky top-0 z-30 border-b border-violet-500/15 bg-[#070414]/80 backdrop-blur-xl">
      <div className="flex items-center gap-3 px-4 py-3 lg:px-6">
        <button
          type="button"
          onClick={onMenu}
          className="flex h-10 w-10 items-center justify-center rounded-xl border border-violet-500/20 bg-white/5 lg:hidden"
          aria-label="القائمة"
        >
          <span className="text-lg">☰</span>
        </button>
        <div className="hidden sm:block">
          <Logo size="sm" />
        </div>
        <form onSubmit={search} className="relative mx-auto min-w-0 flex-1 max-w-xl">
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="ابحث عن لعبتك المفضلة..."
            className="w-full rounded-full border border-violet-400/20 bg-[#120d28] py-2.5 pr-4 pl-11 text-sm text-white placeholder:text-violet-200/40"
          />
          <button
            type="submit"
            className="absolute top-1/2 left-2 -translate-y-1/2 rounded-full p-1.5 text-violet-200/70"
            aria-label="بحث"
          >
            <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="11" cy="11" r="7" />
              <path d="M20 20l-3-3" />
            </svg>
          </button>
        </form>
        <nav className="hidden items-center gap-6 text-sm font-semibold text-violet-100/80 xl:flex">
          {NAV.map((item) => {
            const active = pathname === item.href;
            return (
              <Link
                key={item.href}
                href={item.href}
                className={active ? "nav-active pb-1" : "pb-1 hover:text-white"}
              >
                {item.label}
              </Link>
            );
          })}
        </nav>
        <Link
          href="/cart"
          className="relative flex h-10 w-10 items-center justify-center rounded-full border border-violet-400/20 bg-white/5"
          aria-label="السلة"
        >
          <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="1.8">
            <path d="M6 6h15l-1.5 9h-12z" />
            <path d="M6 6 5 3H2" />
            <circle cx="9" cy="20" r="1.3" fill="currentColor" />
            <circle cx="18" cy="20" r="1.3" fill="currentColor" />
          </svg>
          {count > 0 && (
            <span className="absolute -top-1 -right-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-violet-500 px-1 text-[10px] font-black">
              {count}
            </span>
          )}
        </Link>
        <Link
          href="/account"
          className="flex h-10 w-10 items-center justify-center rounded-full border border-violet-400/20 bg-white/5"
          aria-label="حسابي"
        >
          <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="1.8">
            <circle cx="12" cy="8" r="3.2" />
            <path d="M5 19c1.5-3.2 4-5 7-5s5.5 1.8 7 5" />
          </svg>
        </Link>
      </div>
    </header>
  );
}
