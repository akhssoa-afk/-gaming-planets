import { db } from "@/db";
import { games, type Game } from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import { and, asc, desc, eq, ilike, or, sql } from "drizzle-orm";

export async function getAllGames(): Promise<Game[]> {
  await ensureSeeded();
  return db.select().from(games).orderBy(desc(games.featured), desc(games.hot), asc(games.title));
}

export async function getFeaturedGames(): Promise<Game[]> {
  await ensureSeeded();
  return db.select().from(games).where(eq(games.featured, true)).orderBy(asc(games.id));
}

export async function getGameBySlug(slug: string): Promise<Game | undefined> {
  await ensureSeeded();
  const rows = await db.select().from(games).where(eq(games.slug, slug)).limit(1);
  return rows[0];
}

export async function getGameById(id: number): Promise<Game | undefined> {
  const rows = await db.select().from(games).where(eq(games.id, id)).limit(1);
  return rows[0];
}

export async function queryGames(opts: {
  category?: string;
  platform?: string;
  publisher?: string;
  q?: string;
  offers?: boolean;
}) {
  await ensureSeeded();
  const filters = [];
  if (opts.category && opts.category !== "all") {
    filters.push(eq(games.category, opts.category));
  }
  if (opts.publisher) {
    filters.push(eq(games.publisher, opts.publisher));
  }
  if (opts.q) {
    const term = `%${opts.q.trim()}%`;
    const search = or(
      ilike(games.title, term),
      ilike(games.titleAr, term),
      ilike(games.publisher, term),
    );
    if (search) filters.push(search);
  }
  if (opts.offers) {
    filters.push(sql`${games.originalPrice} > ${games.price}`);
  }

  let rows = await db
    .select()
    .from(games)
    .where(filters.length ? and(...filters) : undefined)
    .orderBy(desc(games.featured), desc(games.hot), asc(games.title));

  if (opts.platform) {
    rows = rows.filter((g) => g.platforms.includes(opts.platform as string));
  }
  return rows;
}
