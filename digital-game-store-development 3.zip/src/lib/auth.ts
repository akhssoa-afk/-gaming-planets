import { createHmac, timingSafeEqual } from "crypto";
import { cookies } from "next/headers";

const SECRET = process.env.ADMIN_SECRET || "gaming-planets-admin-secret-2026";
const USER = process.env.ADMIN_USERNAME || "admin";
const PASS = process.env.ADMIN_PASSWORD || "Planets@2026";

export const ADMIN_COOKIE = "gp_admin";

export function verifyCredentials(username: string, password: string) {
  return username === USER && password === PASS;
}

export function createSessionToken() {
  const exp = Date.now() + 7 * 24 * 60 * 60 * 1000;
  const payload = `admin:${exp}`;
  const sig = createHmac("sha256", SECRET).update(payload).digest("hex");
  return `${payload}:${sig}`;
}

export function verifySessionToken(token: string | undefined | null) {
  if (!token) return false;
  const parts = token.split(":");
  if (parts.length !== 3) return false;
  const [user, exp, sig] = parts;
  const payload = `${user}:${exp}`;
  const expected = createHmac("sha256", SECRET).update(payload).digest("hex");
  try {
    const a = Buffer.from(expected);
    const b = Buffer.from(sig);
    if (a.length !== b.length) return false;
    if (!timingSafeEqual(a, b)) return false;
  } catch {
    return false;
  }
  if (Date.now() > Number(exp)) return false;
  return user === "admin";
}

export async function getAdminSession() {
  const jar = await cookies();
  return verifySessionToken(jar.get(ADMIN_COOKIE)?.value);
}

export async function requireAdmin() {
  const ok = await getAdminSession();
  if (!ok) {
    const { redirect } = await import("next/navigation");
    redirect("/admin/login");
  }
}
