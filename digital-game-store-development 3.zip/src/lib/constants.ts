export const STORE = {
  name: "Gaming Planets",
  nameAr: "قيمنق بلانتس",
  whatsapp: "0582640058",
  whatsappIntl: "966582640058",
  email: "mo702aa@gmail.com",
  currency: "﷼",
};

export const WHATSAPP_URL = `https://wa.me/${STORE.whatsappIntl}`;

export function whatsappLink(text?: string) {
  if (!text) return WHATSAPP_URL;
  return `${WHATSAPP_URL}?text=${encodeURIComponent(text)}`;
}

export const CATEGORIES = [
  { key: "all", label: "الكل", hue: 265 },
  { key: "action", label: "ألعاب الأكشن", hue: 0 },
  { key: "adventure", label: "المغامرات", hue: 210 },
  { key: "rpg", label: "RPG", hue: 280 },
  { key: "racing", label: "السباقات", hue: 28 },
  { key: "sports", label: "الرياضة", hue: 140 },
  { key: "simulation", label: "المحاكاة", hue: 220 },
  { key: "puzzle", label: "الألغاز", hue: 170 },
  { key: "strategy", label: "الألعاب الاستراتيجية", hue: 25 },
  { key: "fighting", label: "الألعاب القتالية", hue: 350 },
] as const;

export const PLATFORMS = [
  { key: "steam", label: "Steam", color: "#66c0f4" },
  { key: "playstation", label: "PlayStation", color: "#0070d1" },
  { key: "xbox", label: "Xbox", color: "#107c10" },
  { key: "nintendo", label: "Nintendo", color: "#e60012" },
] as const;

export const PUBLISHERS = [
  { key: "activision", label: "Activision", labelAr: "أكتيفجن" },
  { key: "ea", label: "EA", labelAr: "إي إيه" },
  { key: "sony", label: "Sony", labelAr: "سوني" },
  { key: "xbox", label: "Xbox", labelAr: "إكس بوكس" },
  { key: "rockstar", label: "Rockstar", labelAr: "روكستار" },
  { key: "ubisoft", label: "Ubisoft", labelAr: "يوبي سوفت" },
  { key: "fromsoftware", label: "FromSoftware", labelAr: "فروم سوفتوير" },
  { key: "cdprojekt", label: "CD Projekt", labelAr: "سي دي بروجكت" },
  { key: "nintendo", label: "Nintendo", labelAr: "نينتندو" },
  { key: "valve", label: "Valve", labelAr: "فالف" },
  { key: "capcom", label: "Capcom", labelAr: "كابكوم" },
  { key: "squareenix", label: "Square Enix", labelAr: "سكوير إنكس" },
  { key: "bandainamco", label: "Bandai Namco", labelAr: "بانداي نامكو" },
  { key: "2k", label: "2K", labelAr: "تو كي" },
  { key: "warner", label: "Warner Bros", labelAr: "وارنر براذرز" },
  { key: "konami", label: "Konami", labelAr: "كونامي" },
  { key: "larian", label: "Larian", labelAr: "لاريان" },
] as const;

export const PAYMENTS = [
  { key: "mastercard", label: "ماستر كارد", labelEn: "Mastercard" },
  { key: "applepay", label: "آبل باي", labelEn: "Apple Pay" },
] as const;

export type CategoryKey = (typeof CATEGORIES)[number]["key"];
export type PlatformKey = (typeof PLATFORMS)[number]["key"];
export type PublisherKey = (typeof PUBLISHERS)[number]["key"];

export function discountOf(price: number, original: number) {
  if (!original || original <= price) return 0;
  return Math.round(((original - price) / original) * 100);
}
