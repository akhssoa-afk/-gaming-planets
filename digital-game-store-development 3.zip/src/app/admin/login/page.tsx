"use client";

import { FormEvent, useState } from "react";
import { useRouter } from "next/navigation";
import { Logo } from "@/components/logo";

export default function AdminLoginPage() {
  const router = useRouter();
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError("");
    setLoading(true);
    const form = new FormData(e.currentTarget);
    const res = await fetch("/api/admin/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        username: form.get("username"),
        password: form.get("password"),
      }),
    });
    if (!res.ok) {
      setError("بيانات الدخول غير صحيحة");
      setLoading(false);
      return;
    }
    router.push("/admin");
    router.refresh();
  }

  return (
    <div className="grid min-h-screen place-items-center px-4">
      <form onSubmit={onSubmit} className="card-glow w-full max-w-sm rounded-3xl p-8">
        <div className="mb-6 flex justify-center">
          <Logo />
        </div>
        <h1 className="text-center text-xl font-black">لوحة التحكم</h1>
        <p className="mt-1 text-center text-xs text-violet-200/50">دخول المالك فقط — غير ظاهرة للعملاء</p>
        <label className="mt-6 block text-sm">
          اسم المستخدم
          <input
            name="username"
            required
            className="mt-1 w-full rounded-xl border border-violet-500/20 bg-[#0d0a1c] px-3 py-2.5"
          />
        </label>
        <label className="mt-4 block text-sm">
          كلمة المرور
          <input
            name="password"
            type="password"
            required
            className="mt-1 w-full rounded-xl border border-violet-500/20 bg-[#0d0a1c] px-3 py-2.5"
          />
        </label>
        {error && <p className="mt-3 text-sm text-red-400">{error}</p>}
        <button disabled={loading} className="glow-btn mt-6 w-full rounded-full py-3 font-bold">
          {loading ? "جارٍ الدخول..." : "دخول"}
        </button>
      </form>
    </div>
  );
}
