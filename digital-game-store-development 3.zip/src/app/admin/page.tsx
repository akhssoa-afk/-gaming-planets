import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { db } from "@/db";
import { games, orders } from "@/db/schema";
import { ADMIN_COOKIE, verifySessionToken } from "@/lib/auth";
import { AdminShell } from "@/components/admin-shell";
import { ensureSeeded } from "@/db/seed";
import { desc, sql } from "drizzle-orm";
import Link from "next/link";

export const dynamic = "force-dynamic";

export default async function AdminHome() {
  const jar = await cookies();
  if (!verifySessionToken(jar.get(ADMIN_COOKIE)?.value)) redirect("/admin/login");
  await ensureSeeded();

  const [{ gamesCount }] = await db.select({ gamesCount: sql<number>`count(*)` }).from(games);
  const [{ ordersCount }] = await db.select({ ordersCount: sql<number>`count(*)` }).from(orders);
  const [{ revenue }] = await db
    .select({ revenue: sql<number>`coalesce(sum(${orders.total}), 0)` })
    .from(orders);
  const latest = await db.select().from(orders).orderBy(desc(orders.createdAt)).limit(5);

  return (
    <AdminShell>
      <h1 className="text-2xl font-black">لوحة تحكم Gaming Planets</h1>
      <p className="mt-1 text-sm text-violet-200/60">خاصة بك فقط. العملاء لا يرون هذا القسم.</p>
      <div className="mt-6 grid gap-4 md:grid-cols-3">
        <div className="card-glow rounded-2xl p-5">
          <p className="text-sm text-violet-200/60">عدد الألعاب</p>
          <p className="mt-1 text-3xl font-black">{Number(gamesCount)}</p>
        </div>
        <div className="card-glow rounded-2xl p-5">
          <p className="text-sm text-violet-200/60">الطلبات</p>
          <p className="mt-1 text-3xl font-black">{Number(ordersCount)}</p>
        </div>
        <div className="card-glow rounded-2xl p-5">
          <p className="text-sm text-violet-200/60">إجمالي المبيعات</p>
          <p className="mt-1 text-3xl font-black">{Number(revenue)} ﷼</p>
        </div>
      </div>
      <div className="mt-6 flex gap-3">
        <Link href="/admin/games" className="glow-btn rounded-full px-5 py-2.5 text-sm font-bold">
          تعديل صور الألعاب
        </Link>
        <Link href="/admin/orders" className="rounded-full border border-violet-500/30 px-5 py-2.5 text-sm">
          عرض الطلبات
        </Link>
      </div>
      <h2 className="mt-10 mb-3 font-black">آخر الطلبات</h2>
      <div className="space-y-2">
        {latest.length === 0 && <p className="text-sm text-violet-200/50">لا توجد طلبات بعد.</p>}
        {latest.map((o) => (
          <div key={o.id} className="card-glow flex items-center justify-between rounded-2xl px-4 py-3 text-sm">
            <span>
              #{o.id} — {o.customerName} — {o.phone}
            </span>
            <span className="font-bold text-violet-300">{o.total} ﷼</span>
          </div>
        ))}
      </div>
    </AdminShell>
  );
}
