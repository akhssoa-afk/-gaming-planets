import { cookies } from "next/headers";
import { notFound, redirect } from "next/navigation";
import { db } from "@/db";
import { games } from "@/db/schema";
import { ADMIN_COOKIE, verifySessionToken } from "@/lib/auth";
import { AdminShell } from "@/components/admin-shell";
import { eq } from "drizzle-orm";
import { GameEditor } from "@/components/game-editor";

export const dynamic = "force-dynamic";

export default async function EditGamePage({ params }: { params: Promise<{ id: string }> }) {
  const jar = await cookies();
  if (!verifySessionToken(jar.get(ADMIN_COOKIE)?.value)) redirect("/admin/login");
  const { id } = await params;
  if (id === "new") {
    return (
      <AdminShell>
        <h1 className="mb-4 text-2xl font-black">إضافة لعبة</h1>
        <GameEditor />
      </AdminShell>
    );
  }
  const gameId = Number(id);
  const [game] = await db.select().from(games).where(eq(games.id, gameId)).limit(1);
  if (!game) notFound();
  return (
    <AdminShell>
      <h1 className="mb-4 text-2xl font-black">تعديل: {game.titleAr}</h1>
      <GameEditor game={game} />
    </AdminShell>
  );
}
