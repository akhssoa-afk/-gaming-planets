import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import Link from "next/link";
import { db } from "@/db";
import { games } from "@/db/schema";
import { ADMIN_COOKIE, verifySessionToken } from "@/lib/auth";
import { AdminShell } from "@/components/admin-shell";
import { ensureSeeded } from "@/db/seed";
import { asc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export default async function AdminGamesPage() {
  const jar = await cookies();
  if (!verifySessionToken(jar.get(ADMIN_COOKIE)?.value)) redirect("/admin/login");
  await ensureSeeded();
  const rows = await db.select().from(games).orderBy(asc(games.id));

  return (
    <AdminShell>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-black">الألعاب والصور</h1>
          <p className="text-sm text-violet-200/60">غيّر صور الألعاب والأسعار من هنا. الصفحة مخفية عن العملاء.</p>
        </div>
        <Link href="/admin/games/new" className="glow-btn rounded-full px-4 py-2 text-sm font-bold">
          إضافة لعبة
        </Link>
      </div>
      <div className="mt-6 overflow-x-auto rounded-3xl border border-violet-500/15">
        <table className="w-full min-w-[720px] text-right text-sm">
          <thead className="bg-white/5 text-violet-200/70">
            <tr>
              <th className="p-3">الصورة</th>
              <th className="p-3">اللعبة</th>
              <th className="p-3">السعر</th>
              <th className="p-3">الناشر</th>
              <th className="p-3">منصات</th>
              <th className="p-3"></th>
            </tr>
          </thead>
          <tbody>
            {rows.map((g) => (
              <tr key={g.id} className="border-t border-violet-500/10">
                <td className="p-3">
                  <img src={g.imageUrl} alt="" className="h-16 w-12 rounded-lg object-cover" />
                </td>
                <td className="p-3">
                  <p className="font-bold">{g.titleAr}</p>
                  <p className="text-xs text-violet-200/50">{g.title}</p>
                </td>
                <td className="p-3 font-black text-violet-300">{g.price} ﷼</td>
                <td className="p-3">{g.publisher}</td>
                <td className="p-3 text-xs">{g.platforms.join(" · ")}</td>
                <td className="p-3">
                  <Link href={`/admin/games/${g.id}`} className="rounded-full bg-violet-600/30 px-3 py-1.5 text-xs font-bold">
                    تعديل الصورة
                  </Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </AdminShell>
  );
}
