import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { ADMIN_COOKIE, verifySessionToken } from "@/lib/auth";
import { AdminShell } from "@/components/admin-shell";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export default async function AdminOrdersPage() {
  const jar = await cookies();
  if (!verifySessionToken(jar.get(ADMIN_COOKIE)?.value)) redirect("/admin/login");
  const rows = await db.select().from(orders).orderBy(desc(orders.createdAt));

  return (
    <AdminShell>
      <h1 className="text-2xl font-black">الطلبات</h1>
      <div className="mt-6 space-y-3">
        {rows.length === 0 && <p className="text-violet-200/50">لا توجد طلبات بعد.</p>}
        {rows.map((o) => (
          <article key={o.id} className="card-glow rounded-2xl p-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <p className="font-black">
                #{o.id} — {o.customerName}
              </p>
              <p className="text-violet-300 font-black">{o.total} ﷼</p>
            </div>
            <p className="mt-1 text-sm text-violet-200/60" dir="ltr">
              {o.phone} · {o.email || "بدون إيميل"} · {o.paymentMethod === "applepay" ? "آبل باي" : "ماستر كارد"} ·{" "}
              {o.status}
            </p>
            <ul className="mt-2 text-sm text-violet-100/80">
              {o.items.map((i) => (
                <li key={`${o.id}-${i.gameId}`}>
                  {i.titleAr} × {i.qty} — {i.price * i.qty} ﷼
                </li>
              ))}
            </ul>
          </article>
        ))}
      </div>
    </AdminShell>
  );
}
