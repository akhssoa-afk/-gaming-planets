import Link from "next/link";
import { StoreFrame } from "@/components/store-frame";
import { CategoryPlanets } from "@/components/category-planets";
import { GameCard } from "@/components/game-card";
import { getAllGames, getFeaturedGames } from "@/lib/games";
import { PUBLISHERS } from "@/lib/constants";
import { PlaystationIcon, SteamIcon, XboxIcon } from "@/components/platform-icons";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const [featured, all] = await Promise.all([getFeaturedGames(), getAllGames()]);
  const hot = all.filter((g) => g.hot && !g.featured).slice(0, 6);

  return (
    <StoreFrame>
      <section className="relative overflow-hidden rounded-[28px] border border-violet-500/20">
        <img
          src="/images/hero-controller.jpg"
          alt=""
          className="absolute inset-0 h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-l from-[#12081f]/30 via-[#0b0618]/55 to-[#070414]/90" />
        <div className="relative grid min-h-[420px] gap-6 p-6 lg:grid-cols-2 lg:p-10">
          <div className="flex flex-col justify-center">
            <p className="text-sm font-semibold text-violet-200/80">مرحباً بك في متجر</p>
            <h1 className="mt-1 bg-gradient-to-l from-white via-violet-200 to-fuchsia-300 bg-clip-text text-5xl font-black text-transparent lg:text-6xl">
              Gaming Planets
            </h1>
            <p className="mt-3 max-w-md text-lg text-violet-50/85">كل ألعابك المفضلة في مكان واحد</p>
            <div className="mt-5 flex flex-wrap gap-3 text-xs text-violet-100/80">
              <span className="flex items-center gap-2 rounded-full bg-black/30 px-3 py-1.5 backdrop-blur">
                🛡️ دفع آمن · جميع طرق الدفع
              </span>
              <span className="flex items-center gap-2 rounded-full bg-black/30 px-3 py-1.5 backdrop-blur">
                ⚡ تسليم فوري بعد الشراء مباشرة
              </span>
              <span className="flex items-center gap-2 rounded-full bg-black/30 px-3 py-1.5 backdrop-blur">
                🎧 دعم 24/7 نحن دائماً معك
              </span>
            </div>
            <Link href="/games" className="glow-btn mt-7 inline-flex w-fit items-center gap-2 rounded-full px-6 py-3 font-bold">
              تسوق الآن ←
            </Link>
          </div>
          <div className="hidden items-center justify-end lg:flex">
            <p className="max-w-sm text-right text-5xl leading-tight font-black tracking-tight text-white/90">
              PLAY
              <br />
              <span className="bg-gradient-to-l from-fuchsia-400 to-violet-300 bg-clip-text text-transparent">
                EXPLORE
              </span>
              <br />
              ENJOY
            </p>
          </div>
        </div>
      </section>

      <section className="mt-8">
        <CategoryPlanets />
      </section>

      <section className="mt-10">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="flex items-center gap-2 text-xl font-black">
            <span className="text-orange-400">🔥</span> أشهر الألعاب
          </h2>
          <Link href="/games" className="text-sm text-violet-200/70 hover:text-white">
            عرض الكل ←
          </Link>
        </div>
        <div className="grid grid-cols-2 gap-4 md:grid-cols-3 xl:grid-cols-6">
          {featured.map((game) => (
            <GameCard key={game.id} game={game} />
          ))}
        </div>
      </section>

      <section className="mt-8 grid gap-4 lg:grid-cols-3">
        <Link href="/publishers/ea" className="relative min-h-[160px] overflow-hidden rounded-3xl border border-violet-500/20">
          <img src="/images/banners/fc-stadium.jpg" alt="" className="absolute inset-0 h-full w-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-l from-black/20 to-[#070414]/85" />
          <div className="relative p-6">
            <p className="text-2xl font-black">EA SPORTS FC 26</p>
            <p className="mt-1 text-sm text-violet-100/80">استعد للموسم الجديد</p>
            <span className="glow-btn mt-4 inline-flex rounded-full px-4 py-2 text-sm font-bold">تسوق الآن ←</span>
          </div>
        </Link>
        <Link href="/platforms/playstation" className="relative min-h-[160px] overflow-hidden rounded-3xl border border-violet-500/20">
          <img src="/images/ps5-banner.jpg" alt="" className="absolute inset-0 h-full w-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-l from-black/10 to-[#041428]/85" />
          <div className="relative p-6">
            <p className="flex items-center gap-2 text-2xl font-black">
              <PlaystationIcon className="h-7 w-7 text-sky-400" /> PlayStation
            </p>
            <p className="mt-1 text-sm text-violet-100/80">ألعاب بلا حدود · حصريات سوني</p>
            <span className="glow-btn mt-4 inline-flex rounded-full px-4 py-2 text-sm font-bold">تسوق الآن ←</span>
          </div>
        </Link>
        <Link href="/platforms/steam" className="relative min-h-[160px] overflow-hidden rounded-3xl border border-violet-500/20">
          <img src="/images/banners/steam-setup.jpg" alt="" className="absolute inset-0 h-full w-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-l from-black/10 to-[#071018]/85" />
          <div className="relative p-6">
            <p className="flex items-center gap-2 text-2xl font-black">
              <SteamIcon className="h-7 w-7" /> STEAM
            </p>
            <p className="mt-1 text-sm text-violet-100/80">اكتشف آلاف الألعاب</p>
            <span className="glow-btn mt-4 inline-flex rounded-full px-4 py-2 text-sm font-bold">تسوق الآن ←</span>
          </div>
        </Link>
      </section>

      <section className="mt-10">
        <h2 className="mb-4 text-xl font-black">ناشرون وحصريات</h2>
        <div className="grid grid-cols-2 gap-3 md:grid-cols-4 xl:grid-cols-5">
          {PUBLISHERS.slice(0, 5).map((p) => (
            <Link
              key={p.key}
              href={`/publishers/${p.key}`}
              className="card-glow rounded-2xl px-4 py-5 text-center transition hover:-translate-y-0.5"
            >
              <p className="text-lg font-black">{p.label}</p>
              <p className="text-sm text-violet-200/60">{p.labelAr} وحصرياتها</p>
            </Link>
          ))}
        </div>
      </section>

      {hot.length > 0 && (
        <section className="mt-10">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-xl font-black">عروض ساخنة</h2>
            <Link href="/offers" className="text-sm text-violet-200/70">
              كل العروض ←
            </Link>
          </div>
          <div className="grid grid-cols-2 gap-4 md:grid-cols-3 xl:grid-cols-6">
            {hot.map((game) => (
              <GameCard key={game.id} game={game} />
            ))}
          </div>
        </section>
      )}

      <section className="mt-10 grid gap-4 md:grid-cols-3">
        <Link href="/platforms/xbox" className="relative overflow-hidden rounded-3xl border border-violet-500/20 p-6">
          <img src="/images/banners/xbox.jpg" alt="" className="absolute inset-0 h-full w-full object-cover opacity-40" />
          <div className="relative">
            <XboxIcon className="h-8 w-8 text-green-500" />
            <p className="mt-2 text-2xl font-black">Xbox</p>
            <p className="text-sm text-violet-100/70">حصريات إكس بوكس وجيم باس</p>
          </div>
        </Link>
        <Link href="/publishers/activision" className="card-glow rounded-3xl p-6">
          <p className="text-sm text-orange-300">أكتيفجن</p>
          <p className="mt-1 text-2xl font-black">Call of Duty وأكثر</p>
          <p className="mt-2 text-sm text-violet-100/70">بلاك أوبس، وورزون، كراش وسبايرو</p>
        </Link>
        <Link href="/publishers/ea" className="card-glow rounded-3xl p-6">
          <p className="text-sm text-sky-300">EA</p>
          <p className="mt-1 text-2xl font-black">FC 26 وحصريات EA</p>
          <p className="mt-2 text-sm text-violet-100/70">فيفا، باتلفيلد، سيمز، نيد فور سبيد</p>
        </Link>
      </section>
    </StoreFrame>
  );
}
