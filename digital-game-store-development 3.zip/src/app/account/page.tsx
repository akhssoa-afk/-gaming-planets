import Link from "next/link";
import { StoreFrame } from "@/components/store-frame";
import { STORE, whatsappLink } from "@/lib/constants";

export default function AccountPage() {
  return (
    <StoreFrame>
      <h1 className="text-3xl font-black">حسابي</h1>
      <div className="card-glow mt-6 max-w-xl rounded-3xl p-6">
        <p className="leading-8 text-violet-100/75">
          المتجر رقمي بالكامل. لتتبع طلبك أو استلام كود اللعبة تواصل معنا على واتساب مباشرة.
        </p>
        <a
          href={whatsappLink("مرحباً، أريد الاستفسار عن طلبي")}
          target="_blank"
          rel="noreferrer"
          className="glow-btn mt-5 inline-flex rounded-full px-6 py-3 font-bold"
        >
          واتساب {STORE.whatsapp}
        </a>
        <p className="mt-4 text-sm text-violet-200/50">
          الإيميل:{" "}
          <a href={`mailto:${STORE.email}`} className="underline">
            {STORE.email}
          </a>
        </p>
        <Link href="/support" className="mt-3 block text-sm text-violet-300">
          صفحة الدعم ←
        </Link>
      </div>
    </StoreFrame>
  );
}
