import Link from "next/link";
import { StoreFrame } from "@/components/store-frame";
import { PUBLISHERS } from "@/lib/constants";

export default function PublishersPage() {
  return (
    <StoreFrame>
      <h1 className="text-3xl font-black">الناشرون والحصريات</h1>
      <p className="mt-2 text-violet-200/70">أكتيفجن، EA، سوني، إكس بوكس وجميع الحصريات.</p>
      <div className="mt-8 grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {PUBLISHERS.map((p) => (
          <Link key={p.key} href={`/publishers/${p.key}`} className="card-glow rounded-3xl p-6">
            <p className="text-2xl font-black">{p.label}</p>
            <p className="text-sm text-violet-200/60">{p.labelAr} وحصرياتها</p>
          </Link>
        ))}
      </div>
    </StoreFrame>
  );
}
