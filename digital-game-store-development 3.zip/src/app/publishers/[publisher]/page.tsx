import { notFound } from "next/navigation";
import { StoreFrame } from "@/components/store-frame";
import { GameCard } from "@/components/game-card";
import { queryGames } from "@/lib/games";
import { PUBLISHERS } from "@/lib/constants";

export const dynamic = "force-dynamic";

export default async function PublisherPage({
  params,
}: {
  params: Promise<{ publisher: string }>;
}) {
  const { publisher } = await params;
  const meta = PUBLISHERS.find((p) => p.key === publisher);
  if (!meta) notFound();
  const games = await queryGames({ publisher });

  return (
    <StoreFrame>
      <h1 className="text-3xl font-black">
        {meta.label} — {meta.labelAr}
      </h1>
      <p className="mt-2 text-violet-200/70">ألعاب {meta.labelAr} وحصرياتها في Gaming Planets.</p>
      <div className="mt-8 grid grid-cols-2 gap-4 md:grid-cols-3 xl:grid-cols-5">
        {games.map((game) => (
          <GameCard key={game.id} game={game} />
        ))}
      </div>
    </StoreFrame>
  );
}
