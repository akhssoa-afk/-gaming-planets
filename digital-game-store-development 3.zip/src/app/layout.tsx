import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Cairo } from "next/font/google";
import "./globals.css";
import { CartProvider } from "@/components/cart-provider";
import { WhatsAppButton } from "@/components/whatsapp-button";

const cairo = Cairo({
  subsets: ["arabic", "latin"],
  weight: ["400", "500", "600", "700", "800", "900"],
  variable: "--font-cairo",
});

export const metadata: Metadata = {
  title: "Gaming Planets | متجر الألعاب الرقمية",
  description:
    "متجر Gaming Planets للألعاب الرقمية: ستيم، بلايستيشن، إكس بوكس. أكتيفجن، EA وحصرياتها. تسليم فوري ودعم واتساب.",
  icons: { icon: "/images/logo-alien.png" },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ar" className={cairo.variable}>
      <body className={`${cairo.className} antialiased`}>
        <CartProvider>
          {children}
          <WhatsAppButton />
        </CartProvider>
      </body>
    </html>
  );
}
