import { notFound } from "next/navigation";
import { StoreFrame } from "@/components/store-frame";
import { GameCard } from "@/components/game-card";
import { queryGames } from "@/lib/games";
import { PLATFORMS } from "@/lib/constants";

export const dynamic = "force-dynamic";

export default async function PlatformPage({
  params,
}: {
  params: Promise<{ platform: string }>;
}) {
  const { platform } = await params;
  const meta = PLATFORMS.find((p) => p.key === platform);
  if (!meta) notFound();
  const games = await queryGames({ platform });
  const exclusives = games.filter((g) => g.exclusive === platform);

  return (
    <StoreFrame>
      <h1 className="text-3xl font-black">ألعاب {meta.label}</h1>
      <p className="mt-2 text-violet-200/70">
        {games.length} لعبة متوفرة
        {exclusives.length ? ` · منها ${exclusives.length} حصرية` : ""}
      </p>
      {exclusives.length > 0 && (
        <section className="mt-8">
          <h2 className="mb-4 text-xl font-black">حصريات {meta.label}</h2>
          <div className="grid grid-cols-2 gap-4 md:grid-cols-3 xl:grid-cols-5">
            {exclusives.map((game) => (
              <GameCard key={game.id} game={game} />
            ))}
          </div>
        </section>
      )}
      <section className="mt-10">
        <h2 className="mb-4 text-xl font-black">كل الألعاب</h2>
        <div className="grid grid-cols-2 gap-4 md:grid-cols-3 xl:grid-cols-5">
          {games.map((game) => (
            <GameCard key={game.id} game={game} />
          ))}
        </div>
      </section>
    </StoreFrame>
  );
}
