import Link from "next/link";
import { StoreFrame } from "@/components/store-frame";
import { PLATFORMS } from "@/lib/constants";
import { PlatformGlyph } from "@/components/platform-icons";

export default function PlatformsPage() {
  return (
    <StoreFrame>
      <h1 className="text-3xl font-black">المنصات</h1>
      <p className="mt-2 text-violet-200/70">ستيم، سوني بلايستيشن، إكس بوكس ونينتندو.</p>
      <div className="mt-8 grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        {PLATFORMS.map((p) => (
          <Link key={p.key} href={`/platforms/${p.key}`} className="card-glow rounded-3xl p-8 text-center">
            <span className="mx-auto grid h-16 w-16 place-items-center rounded-2xl bg-white/5" style={{ color: p.color }}>
              <PlatformGlyph platform={p.key} className="h-8 w-8" />
            </span>
            <p className="mt-4 text-2xl font-black">{p.label}</p>
            <p className="mt-1 text-sm text-violet-200/60">تصفح ألعاب {p.label}</p>
          </Link>
        ))}
      </div>
    </StoreFrame>
  );
}
