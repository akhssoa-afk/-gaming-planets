"use client";

import Link from "next/link";
import { StoreFrame } from "@/components/store-frame";
import { useCart } from "@/components/cart-provider";

export default function CartPage() {
  const { items, remove, setQty, total } = useCart();

  return (
    <StoreFrame>
      <h1 className="text-3xl font-black">سلة المشتريات</h1>
      {items.length === 0 ? (
        <div className="card-glow mt-8 rounded-3xl p-10 text-center">
          <p className="text-lg">سلتك فارغة</p>
          <Link href="/games" className="glow-btn mt-4 inline-flex rounded-full px-6 py-3 font-bold">
            تصفح الألعاب
          </Link>
        </div>
      ) : (
        <div className="mt-6 grid gap-6 lg:grid-cols-[1fr_320px]">
          <div className="space-y-3">
            {items.map((item) => (
              <div key={item.gameId} className="card-glow flex gap-4 rounded-2xl p-3">
                <img src={item.imageUrl} alt="" className="h-24 w-20 rounded-xl object-cover" />
                <div className="flex-1">
                  <Link href={`/games/${item.slug}`} className="font-bold">
                    {item.title}
                  </Link>
                  <p className="text-sm text-violet-200/60">{item.titleAr}</p>
                  <p className="mt-1 font-black text-violet-300">{item.price} ﷼</p>
                  <div className="mt-2 flex items-center gap-2">
                    <button
                      className="h-8 w-8 rounded-lg bg-white/5"
                      onClick={() => setQty(item.gameId, item.qty - 1)}
                    >
                      -
                    </button>
                    <span className="w-6 text-center">{item.qty}</span>
                    <button
                      className="h-8 w-8 rounded-lg bg-white/5"
                      onClick={() => setQty(item.gameId, item.qty + 1)}
                    >
                      +
                    </button>
                    <button className="mr-auto text-sm text-red-400" onClick={() => remove(item.gameId)}>
                      حذف
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <aside className="card-glow h-fit rounded-3xl p-5">
            <p className="text-sm text-violet-200/60">الإجمالي</p>
            <p className="mt-1 text-3xl font-black text-violet-300">{total} ﷼</p>
            <Link href="/checkout" className="glow-btn mt-5 flex justify-center rounded-full py-3 font-bold">
              إتمام الشراء
            </Link>
          </aside>
        </div>
      )}
    </StoreFrame>
  );
}
