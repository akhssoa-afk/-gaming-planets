import Link from "next/link";
import { StoreFrame } from "@/components/store-frame";
import { STORE, whatsappLink } from "@/lib/constants";

export default function DonePage() {
  return (
    <StoreFrame>
      <div className="card-glow mx-auto max-w-xl rounded-3xl p-10 text-center">
        <p className="text-5xl">🚀</p>
        <h1 className="mt-3 text-3xl font-black">تم إرسال طلبك</h1>
        <p className="mt-3 text-violet-200/70">
          راسلنا على واتساب {STORE.whatsapp} لتأكيد الدفع بماستر كارد أو آبل باي واستلام اللعبة فوراً.
        </p>
        <a
          href={whatsappLink("مرحباً، أرسلت طلب من المتجر وأريد تأكيد الدفع")}
          target="_blank"
          rel="noreferrer"
          className="glow-btn mt-6 inline-flex rounded-full px-6 py-3 font-bold"
        >
          فتح واتساب
        </a>
        <div className="mt-4">
          <Link href="/games" className="text-sm text-violet-200/70">
            العودة للمتجر
          </Link>
        </div>
      </div>
    </StoreFrame>
  );
}
