"use client";

import { FormEvent, useState } from "react";
import { useRouter } from "next/navigation";
import { StoreFrame } from "@/components/store-frame";
import { useCart } from "@/components/cart-provider";
import { ApplePayMark, MastercardMark } from "@/components/platform-icons";
import { STORE } from "@/lib/constants";

export default function CheckoutPage() {
  const { items, total, clear } = useCart();
  const router = useRouter();
  const [payment, setPayment] = useState<"mastercard" | "applepay">("mastercard");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError("");
    if (items.length === 0) {
      setError("السلة فارغة");
      return;
    }
    const form = new FormData(e.currentTarget);
    setLoading(true);
    try {
      const res = await fetch("/api/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customerName: form.get("name"),
          phone: form.get("phone"),
          email: form.get("email"),
          paymentMethod: payment,
          items: items.map((i) => ({ gameId: i.gameId, qty: i.qty })),
        }),
      });
      const data = (await res.json()) as { ok?: boolean; whatsappUrl?: string; error?: string };
      if (!res.ok || !data.whatsappUrl) {
        setError(data.error || "تعذر إرسال الطلب");
        setLoading(false);
        return;
      }
      clear();
      window.open(data.whatsappUrl, "_blank");
      router.push("/checkout/done");
    } catch {
      setError("حدث خطأ، حاول مرة أخرى");
      setLoading(false);
    }
  }

  return (
    <StoreFrame>
      <h1 className="text-3xl font-black">إتمام الشراء</h1>
      <p className="mt-2 text-sm text-violet-200/60">
        أكّد طلبك بماستر كارد أو آبل باي، ثم راسلنا على واتساب {STORE.whatsapp} لاستلام اللعبة فوراً.
      </p>
      <form onSubmit={onSubmit} className="mt-6 grid gap-6 lg:grid-cols-[1fr_340px]">
        <div className="card-glow space-y-4 rounded-3xl p-5">
          <label className="block text-sm">
            الاسم
            <input
              name="name"
              required
              className="mt-1 w-full rounded-xl border border-violet-500/20 bg-[#0d0a1c] px-3 py-2.5"
            />
          </label>
          <label className="block text-sm">
            رقم الجوال
            <input
              name="phone"
              required
              dir="ltr"
              placeholder="05xxxxxxxx"
              className="mt-1 w-full rounded-xl border border-violet-500/20 bg-[#0d0a1c] px-3 py-2.5"
            />
          </label>
          <label className="block text-sm">
            الإيميل (اختياري)
            <input
              name="email"
              type="email"
              dir="ltr"
              className="mt-1 w-full rounded-xl border border-violet-500/20 bg-[#0d0a1c] px-3 py-2.5"
            />
          </label>
          <div>
            <p className="mb-2 text-sm font-bold">طريقة الدفع</p>
            <div className="grid gap-3 sm:grid-cols-2">
              <button
                type="button"
                onClick={() => setPayment("mastercard")}
                className={`flex items-center justify-between rounded-2xl border px-4 py-3 ${
                  payment === "mastercard" ? "border-violet-400 bg-violet-500/15" : "border-violet-500/20"
                }`}
              >
                <span>ماستر كارد</span>
                <MastercardMark />
              </button>
              <button
                type="button"
                onClick={() => setPayment("applepay")}
                className={`flex items-center justify-between rounded-2xl border px-4 py-3 ${
                  payment === "applepay" ? "border-violet-400 bg-violet-500/15" : "border-violet-500/20"
                }`}
              >
                <span>آبل باي</span>
                <ApplePayMark />
              </button>
            </div>
          </div>
          {error && <p className="text-sm text-red-400">{error}</p>}
          <button disabled={loading} className="glow-btn w-full rounded-full py-3 font-bold disabled:opacity-60">
            {loading ? "جارٍ الإرسال..." : "تأكيد الطلب والتواصل واتساب"}
          </button>
        </div>
        <aside className="card-glow h-fit rounded-3xl p-5">
          <h2 className="font-black">ملخص الطلب</h2>
          <div className="mt-3 space-y-2 text-sm">
            {items.map((i) => (
              <div key={i.gameId} className="flex justify-between text-violet-100/80">
                <span>
                  {i.titleAr} × {i.qty}
                </span>
                <span>{i.price * i.qty} ﷼</span>
              </div>
            ))}
          </div>
          <div className="mt-4 flex justify-between border-t border-violet-500/20 pt-3 text-lg font-black">
            <span>الإجمالي</span>
            <span className="text-violet-300">{total} ﷼</span>
          </div>
        </aside>
      </form>
    </StoreFrame>
  );
}
