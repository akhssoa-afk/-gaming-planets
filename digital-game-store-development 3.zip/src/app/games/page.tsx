import { StoreFrame } from "@/components/store-frame";
import { CategoryPlanets } from "@/components/category-planets";
import { GameCard } from "@/components/game-card";
import { queryGames } from "@/lib/games";
import { CATEGORIES } from "@/lib/constants";

export const dynamic = "force-dynamic";

export default async function GamesPage({
  searchParams,
}: {
  searchParams: Promise<{ category?: string; platform?: string }>;
}) {
  const sp = await searchParams;
  const category = sp.category || "all";
  const games = await queryGames({ category, platform: sp.platform });
  const label = CATEGORIES.find((c) => c.key === category)?.label || "جميع الألعاب";

  return (
    <StoreFrame>
      <h1 className="text-3xl font-black">{label}</h1>
      <p className="mt-1 text-sm text-violet-200/60">{games.length} لعبة رقمية جاهزة للتسليم الفوري</p>
      <div className="mt-6">
        <CategoryPlanets active={category} />
      </div>
      <div className="mt-8 grid grid-cols-2 gap-4 md:grid-cols-3 xl:grid-cols-5">
        {games.map((game) => (
          <GameCard key={game.id} game={game} />
        ))}
      </div>
    </StoreFrame>
  );
}
