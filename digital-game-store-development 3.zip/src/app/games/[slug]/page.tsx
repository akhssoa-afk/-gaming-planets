import Link from "next/link";
import { notFound } from "next/navigation";
import { StoreFrame } from "@/components/store-frame";
import { GameCard } from "@/components/game-card";
import { AddToCartButton } from "@/components/add-to-cart-button";
import { getAllGames, getGameBySlug } from "@/lib/games";
import { discountOf, PUBLISHERS, PLATFORMS } from "@/lib/constants";
import { PlatformGlyph } from "@/components/platform-icons";

export const dynamic = "force-dynamic";

export default async function GamePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const game = await getGameBySlug(slug);
  if (!game) notFound();
  const related = (await getAllGames())
    .filter((g) => g.id !== game.id && (g.publisher === game.publisher || g.category === game.category))
    .slice(0, 6);
  const discount = discountOf(game.price, game.originalPrice);
  const publisher = PUBLISHERS.find((p) => p.key === game.publisher);

  return (
    <StoreFrame>
      <div className="grid gap-8 lg:grid-cols-[360px_1fr]">
        <div className="overflow-hidden rounded-3xl border border-violet-500/20">
          <img src={game.imageUrl} alt={game.titleAr} className="h-full w-full object-cover" />
        </div>
        <div>
          <p className="text-sm text-violet-300">
            {publisher ? `${publisher.labelAr} · ${publisher.label}` : game.publisher}
            {game.exclusive ? " · حصري" : ""}
          </p>
          <h1 className="mt-2 text-4xl font-black">{game.title}</h1>
          <p className="mt-1 text-lg text-violet-100/70">{game.titleAr}</p>
          <div className="mt-4 flex flex-wrap gap-2">
            {game.platforms.map((p) => {
              const meta = PLATFORMS.find((x) => x.key === p);
              return (
                <Link
                  key={p}
                  href={`/platforms/${p}`}
                  className="flex items-center gap-2 rounded-full bg-white/5 px-3 py-1.5 text-sm"
                >
                  <PlatformGlyph platform={p} />
                  {meta?.label || p}
                </Link>
              );
            })}
          </div>
          <p className="mt-5 max-w-2xl leading-8 text-violet-100/80">{game.descriptionAr}</p>
          <div className="mt-6 flex items-end gap-3">
            {discount > 0 && (
              <span className="text-lg text-violet-200/40 line-through">{game.originalPrice} ﷼</span>
            )}
            <span className="text-4xl font-black text-violet-300">{game.price} ﷼</span>
            {discount > 0 && (
              <span className="rounded-lg bg-red-500 px-2 py-1 text-sm font-black">-{discount}%</span>
            )}
          </div>
          <AddToCartButton game={game} />
          <p className="mt-4 text-sm text-violet-200/50">تسليم رقمي فوري عبر واتساب بعد تأكيد الدفع بماستر كارد أو آبل باي.</p>
        </div>
      </div>
      {related.length > 0 && (
        <section className="mt-12">
          <h2 className="mb-4 text-xl font-black">قد يعجبك أيضاً</h2>
          <div className="grid grid-cols-2 gap-4 md:grid-cols-3 xl:grid-cols-6">
            {related.map((g) => (
              <GameCard key={g.id} game={g} />
            ))}
          </div>
        </section>
      )}
    </StoreFrame>
  );
}
