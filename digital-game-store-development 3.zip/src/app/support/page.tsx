import { StoreFrame } from "@/components/store-frame";
import { STORE, whatsappLink } from "@/lib/constants";

export const dynamic = "force-dynamic";

export default function SupportPage() {
  return (
    <StoreFrame>
      <h1 className="text-3xl font-black">الدعم</h1>
      <p className="mt-2 max-w-2xl text-violet-200/70">
        تواصل معنا مباشرة على الخاص عبر واتساب أو الإيميل. الرد سريع وتسليم الأكواد فوري بعد تأكيد الدفع.
      </p>
      <div className="mt-8 grid gap-4 md:grid-cols-2">
        <a
          href={whatsappLink("مرحباً Gaming Planets، أحتاج مساعدة")}
          target="_blank"
          rel="noreferrer"
          className="card-glow rounded-3xl p-6 transition hover:-translate-y-0.5"
        >
          <p className="text-sm text-[#25d366]">واتساب مباشر</p>
          <p className="mt-2 text-3xl font-black" dir="ltr">
            {STORE.whatsapp}
          </p>
          <p className="mt-2 text-sm text-violet-200/60">اضغط للتحدث على الخاص فوراً</p>
        </a>
        <a href={`mailto:${STORE.email}`} className="card-glow rounded-3xl p-6">
          <p className="text-sm text-violet-300">الإيميل</p>
          <p className="mt-2 text-2xl font-black" dir="ltr">
            {STORE.email}
          </p>
          <p className="mt-2 text-sm text-violet-200/60">للاستفسارات والطلبات</p>
        </a>
      </div>
      <div className="card-glow mt-6 rounded-3xl p-6">
        <h2 className="text-xl font-black">كيف يتم الشراء؟</h2>
        <ol className="mt-3 list-decimal pr-5 text-violet-100/75 leading-8">
          <li>اختر اللعبة وأضفها للسلة.</li>
          <li>ادفع بماستر كارد أو آبل باي عبر تأكيد الطلب.</li>
          <li>يصلك الطلب على واتساب ويتم تسليم الكود/الحساب فوراً.</li>
        </ol>
      </div>
    </StoreFrame>
  );
}
