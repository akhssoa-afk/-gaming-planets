import Link from "next/link";
import { StoreFrame } from "@/components/store-frame";

export default function NotFound() {
  return (
    <StoreFrame>
      <div className="card-glow mx-auto max-w-lg rounded-3xl p-10 text-center">
        <p className="text-5xl">👾</p>
        <h1 className="mt-3 text-2xl font-black">الصفحة غير موجودة</h1>
        <Link href="/" className="glow-btn mt-5 inline-flex rounded-full px-6 py-3 font-bold">
          العودة للمتجر
        </Link>
      </div>
    </StoreFrame>
  );
}
