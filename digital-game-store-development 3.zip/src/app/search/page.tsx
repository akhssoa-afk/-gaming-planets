import { StoreFrame } from "@/components/store-frame";
import { GameCard } from "@/components/game-card";
import { queryGames } from "@/lib/games";

export const dynamic = "force-dynamic";

export default async function SearchPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string }>;
}) {
  const { q = "" } = await searchParams;
  const games = q.trim() ? await queryGames({ q }) : [];

  return (
    <StoreFrame>
      <h1 className="text-3xl font-black">نتائج البحث</h1>
      <p className="mt-2 text-violet-200/70">{q ? `عن «${q}» — ${games.length} نتيجة` : "اكتب اسم اللعبة في البحث"}</p>
      <div className="mt-8 grid grid-cols-2 gap-4 md:grid-cols-3 xl:grid-cols-5">
        {games.map((game) => (
          <GameCard key={game.id} game={game} />
        ))}
      </div>
    </StoreFrame>
  );
}
