import { StoreFrame } from "@/components/store-frame";
import { GameCard } from "@/components/game-card";
import { queryGames } from "@/lib/games";

export const dynamic = "force-dynamic";

export default async function OffersPage() {
  const games = await queryGames({ offers: true });
  return (
    <StoreFrame>
      <h1 className="text-3xl font-black">العروض الخاصة 🔥</h1>
      <p className="mt-2 text-violet-200/70">خصومات حقيقية على ألعاب رقمية من 20 إلى 70 ريال.</p>
      <div className="mt-8 grid grid-cols-2 gap-4 md:grid-cols-3 xl:grid-cols-5">
        {games.map((game) => (
          <GameCard key={game.id} game={game} />
        ))}
      </div>
    </StoreFrame>
  );
}
