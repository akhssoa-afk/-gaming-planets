import { db } from "@/db";
import { games, orders } from "@/db/schema";
import { inArray } from "drizzle-orm";
import { whatsappLink } from "@/lib/constants";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  try {
    const body = (await req.json()) as {
      customerName?: string;
      phone?: string;
      email?: string;
      paymentMethod?: string;
      items?: { gameId: number; qty: number }[];
    };

    const customerName = (body.customerName || "").trim();
    const phone = (body.phone || "").trim();
    const paymentMethod = body.paymentMethod === "applepay" ? "applepay" : "mastercard";
    const rawItems = Array.isArray(body.items) ? body.items : [];

    if (!customerName || !phone || rawItems.length === 0) {
      return Response.json({ error: "أكمل البيانات وأضف ألعاباً للسلة" }, { status: 400 });
    }

    const ids = [...new Set(rawItems.map((i) => Number(i.gameId)).filter(Boolean))];
    if (ids.length === 0) {
      return Response.json({ error: "لا توجد ألعاب صالحة في الطلب" }, { status: 400 });
    }
    const dbGames = await db.select().from(games).where(inArray(games.id, ids));
    const byId = new Map(dbGames.map((g) => [g.id, g]));

    const items = rawItems
      .map((i) => {
        const g = byId.get(Number(i.gameId));
        if (!g) return null;
        const qty = Math.max(1, Math.min(10, Number(i.qty) || 1));
        return {
          gameId: g.id,
          title: g.title,
          titleAr: g.titleAr,
          price: g.price,
          qty,
          imageUrl: g.imageUrl,
        };
      })
      .filter((x): x is NonNullable<typeof x> => Boolean(x));

    if (items.length === 0) {
      return Response.json({ error: "لا توجد ألعاب صالحة في الطلب" }, { status: 400 });
    }

    const total = items.reduce((s, i) => s + i.price * i.qty, 0);
    const [order] = await db
      .insert(orders)
      .values({
        customerName,
        phone,
        email: (body.email || "").trim() || null,
        paymentMethod,
        total,
        items,
        status: "pending",
      })
      .returning({ id: orders.id });

    const payLabel = paymentMethod === "applepay" ? "آبل باي" : "ماستر كارد";
    const lines = items.map((i) => `• ${i.titleAr} (${i.title}) × ${i.qty} = ${i.price * i.qty}﷼`).join("\n");
    const text = `طلب جديد #${order.id} من Gaming Planets
الاسم: ${customerName}
الجوال: ${phone}
الدفع: ${payLabel}
${lines}
الإجمالي: ${total}﷼
أريد تأكيد الدفع واستلام الألعاب فوراً.`;

    return Response.json({ ok: true, id: order.id, whatsappUrl: whatsappLink(text) });
  } catch {
    return Response.json({ error: "تعذر إنشاء الطلب" }, { status: 500 });
  }
}
