import { cookies } from "next/headers";
import { ADMIN_COOKIE, createSessionToken, verifyCredentials } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const body = (await req.json()) as { username?: string; password?: string };
  if (!verifyCredentials(body.username || "", body.password || "")) {
    return Response.json({ error: "بيانات الدخول غير صحيحة" }, { status: 401 });
  }
  const jar = await cookies();
  jar.set(ADMIN_COOKIE, createSessionToken(), {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 24 * 7,
  });
  return Response.json({ ok: true });
}
