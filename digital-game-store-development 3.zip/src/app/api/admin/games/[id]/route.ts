import { db } from "@/db";
import { games } from "@/db/schema";
import { getAdminSession } from "@/lib/auth";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

async function guard() {
  const ok = await getAdminSession();
  if (!ok) return Response.json({ error: "غير مصرح" }, { status: 401 });
  return null;
}

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const denied = await guard();
  if (denied) return denied;
  const { id } = await params;
  const gameId = Number(id);
  if (!gameId) return Response.json({ error: "معرف غير صالح" }, { status: 400 });

  const body = (await req.json()) as {
    title?: string;
    titleAr?: string;
    descriptionAr?: string;
    imageUrl?: string;
    publisher?: string;
    category?: string;
    exclusive?: string | null;
    price?: number;
    originalPrice?: number;
    featured?: boolean;
    hot?: boolean;
    platforms?: string[];
  };

  const [current] = await db.select().from(games).where(eq(games.id, gameId)).limit(1);
  if (!current) return Response.json({ error: "اللعبة غير موجودة" }, { status: 404 });

  const [row] = await db
    .update(games)
    .set({
      title: typeof body.title === "string" ? body.title : current.title,
      titleAr: typeof body.titleAr === "string" ? body.titleAr : current.titleAr,
      descriptionAr:
        typeof body.descriptionAr === "string" ? body.descriptionAr : current.descriptionAr,
      imageUrl: typeof body.imageUrl === "string" ? body.imageUrl : current.imageUrl,
      publisher: typeof body.publisher === "string" ? body.publisher : current.publisher,
      category: typeof body.category === "string" ? body.category : current.category,
      exclusive: body.exclusive === undefined ? current.exclusive : body.exclusive,
      price: typeof body.price === "number" ? body.price : current.price,
      originalPrice: typeof body.originalPrice === "number" ? body.originalPrice : current.originalPrice,
      featured: typeof body.featured === "boolean" ? body.featured : current.featured,
      hot: typeof body.hot === "boolean" ? body.hot : current.hot,
      platforms: Array.isArray(body.platforms)
        ? body.platforms.filter((p) => typeof p === "string")
        : current.platforms,
      updatedAt: new Date(),
    })
    .where(eq(games.id, gameId))
    .returning();

  return Response.json({ ok: true, game: row });
}

export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const denied = await guard();
  if (denied) return denied;
  const { id } = await params;
  await db.delete(games).where(eq(games.id, Number(id)));
  return Response.json({ ok: true });
}
