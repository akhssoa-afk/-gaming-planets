import { db } from "@/db";
import { games } from "@/db/schema";
import { getAdminSession } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const ok = await getAdminSession();
  if (!ok) return Response.json({ error: "غير مصرح" }, { status: 401 });

  const body = (await req.json()) as {
    title?: string;
    titleAr?: string;
    slug?: string;
    price?: number;
    originalPrice?: number;
    imageUrl?: string;
    publisher?: string;
    category?: string;
    platforms?: string[];
    descriptionAr?: string;
  };

  const title = (body.title || "").trim();
  const titleAr = (body.titleAr || title).trim();
  if (!title) return Response.json({ error: "العنوان مطلوب" }, { status: 400 });

  const slug =
    (body.slug || title)
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-|-$/g, "") || `game-${Date.now()}`;

  const price = Number(body.price) || 20;
  const originalPrice = Number(body.originalPrice) || price;
  const [row] = await db
    .insert(games)
    .values({
      title,
      titleAr,
      slug,
      description: title,
      descriptionAr: body.descriptionAr || titleAr,
      price,
      originalPrice,
      imageUrl: body.imageUrl || "/images/games/controller.jpg",
      publisher: body.publisher || "ea",
      category: body.category || "action",
      platforms: body.platforms?.length ? body.platforms : ["steam"],
      featured: false,
      hot: false,
    })
    .returning();

  return Response.json({ ok: true, game: row });
}
